import { Ticket, Crown, User } from 'lucide-react';
import { createClient } from '@/lib/supabase/server';
import { BookExperience } from '@/components/book-experience';
import { PageHeader, EmptyState, money } from '@/components/ui';

export default async function Packages() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data } = await supabase.from('packages').select('*').eq('active', true).order('price');
  return (
    <div className="stack">
      <PageHeader eyebrow="Experiences" title="Choose your experience">Reserve instantly with your wallet balance.</PageHeader>
      {data?.length ? (
        <div className="grid grid2">
          {data.map(p => {
            const mg = p.kind === 'meet_greet';
            return (
              <div className="card hover pkg fade-in" key={p.id}>
                <div className={`pkg-art ${mg ? 'mg' : 'fc'}`}>{mg ? <Ticket size={42} color="var(--gold)" /> : <Crown size={42} color="var(--blue)" />}</div>
                <div><span className={`badge ${mg ? 'green' : 'blue'} plain`}>{mg ? 'Meet & Greet' : 'Fan Club'}</span></div>
                <h2 className="display">{p.name}</h2>
                <p className="desc">{p.description}</p>
                <div className="row muted" style={{ fontSize: 13.5 }}><User size={14} />{p.artist_name}</div>
                <div className="pkg-foot">
                  <div><div className="faint" style={{ fontSize: 12 }}>Price</div><div className="price">{money(p.price)}</div></div>
                  <BookExperience packageId={p.id} price={Number(p.price)} title={p.name} userId={user?.id ?? null} />
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="card"><EmptyState title="No experiences available" icon={<Ticket size={22} />}>New experiences will appear here soon.</EmptyState></div>
      )}
    </div>
  );
}
