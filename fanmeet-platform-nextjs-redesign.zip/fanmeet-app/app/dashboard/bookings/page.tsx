import Link from 'next/link';
import { CalendarCheck, Ticket, Crown } from 'lucide-react';
import { createClient } from '@/lib/supabase/server';
import { PageHeader, StatusBadge, EmptyState, money, shortDate, kindLabel } from '@/components/ui';

export default async function Bookings() {
  const s = await createClient();
  const { data: { user } } = await s.auth.getUser();
  const { data } = await s.from('bookings').select('*,packages(name,artist_name,kind,price)').eq('user_id', user!.id).order('created_at', { ascending: false });
  return (
    <div className="stack">
      <PageHeader eyebrow="Reservations" title="My bookings">Everything you&apos;ve reserved, in one place.</PageHeader>
      {data?.length ? (
        <div className="grid">
          {data.map((b: any) => {
            const mg = b.packages?.kind === 'meet_greet';
            return (
              <div className="card hover fade-in" key={b.id}>
                <div className="row between" style={{ alignItems: 'flex-start', flexWrap: 'wrap' }}>
                  <div className="row" style={{ alignItems: 'flex-start' }}>
                    <div className={`icon-box ${mg ? '' : 'blue'}`}>{mg ? <Ticket size={20} /> : <Crown size={20} />}</div>
                    <div>
                      <h3 style={{ fontSize: 18 }}>{b.packages?.name}</h3>
                      <p className="muted" style={{ marginTop: 3 }}>{b.packages?.artist_name} · {kindLabel(b.packages?.kind)}</p>
                    </div>
                  </div>
                  <StatusBadge value={b.status} />
                </div>
                <div className="row between" style={{ marginTop: 18, paddingTop: 16, borderTop: '1px solid var(--line)', flexWrap: 'wrap' }}>
                  <span className="faint mono">#{String(b.id).slice(0, 8)}</span>
                  <span className="muted">{shortDate(b.created_at)}</span>
                  <strong>{money(b.amount ?? b.packages?.price)}</strong>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="card">
          <EmptyState title="No bookings yet" icon={<CalendarCheck size={22} />}>
            <Link href="/dashboard/packages" className="btn primary" style={{ marginTop: 10 }}>Explore experiences</Link>
          </EmptyState>
        </div>
      )}
    </div>
  );
}
