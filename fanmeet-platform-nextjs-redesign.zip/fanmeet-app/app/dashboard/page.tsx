import Link from 'next/link';
import { ArrowDownLeft, ArrowUpRight, Wallet, Plus, Ticket, Activity, ShieldCheck, Receipt } from 'lucide-react';
import { createClient } from '@/lib/supabase/server';
import { getProfile } from '@/lib/auth';
import { WalletBalance } from '@/components/wallet-balance';
import { PageHeader, StatusBadge, EmptyState, money, shortDate } from '@/components/ui';

export default async function Dashboard() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const profile = await getProfile();
  const { data: wallet } = await supabase.from('wallets').select('balance').eq('user_id', user!.id).single();
  const { data: tx } = await supabase.from('wallet_transactions').select('*').eq('user_id', user!.id).order('created_at', { ascending: false }).limit(5);
  const first = (profile?.full_name || '').split(' ')[0];

  return (
    <div className="stack">
      <PageHeader eyebrow="Your account" title={first ? `Welcome back, ${first}` : 'Welcome back'}>
        Here&apos;s a snapshot of your wallet and latest activity.
      </PageHeader>

      <div className="grid grid3 fade-in">
        <div className="card balance-card span2">
          <div className="stat-label"><span>Available balance</span><span className="icon-box"><Wallet size={19} /></span></div>
          <WalletBalance userId={user!.id} initialBalance={Number(wallet?.balance || 0)} />
          <div className="quick">
            <Link href="/dashboard/deposit" className="btn primary"><Plus size={16} />Add funds</Link>
            <Link href="/dashboard/packages" className="btn"><Ticket size={16} />Browse experiences</Link>
          </div>
        </div>
        <div className="grid" style={{ gridTemplateRows: '1fr 1fr' }}>
          <div className="card">
            <div className="stat-label"><span>Wallet status</span><ShieldCheck size={18} color="var(--green)" /></div>
            <div className="stat" style={{ fontSize: 24, marginTop: 12 }}>Active</div>
          </div>
          <div className="card">
            <div className="stat-label"><span>Recent activity</span><Activity size={18} color="var(--gold)" /></div>
            <div className="stat" style={{ fontSize: 24, marginTop: 12 }}>{tx?.length || 0} <span className="muted" style={{ fontSize: 14, fontWeight: 500 }}>transactions</span></div>
          </div>
        </div>
      </div>

      <div className="card flush fade-in">
        <div className="card-head"><h3>Recent transactions</h3><Link href="/dashboard/bookings" className="btn sm ghost">View bookings</Link></div>
        {tx?.length ? (
          <div className="table-wrap">
            <table className="table">
              <thead><tr><th>Transaction</th><th>Date</th><th>Type</th><th className="num">Amount</th></tr></thead>
              <tbody>
                {tx.map((t: any) => {
                  const amt = Number(t.amount);
                  return (
                    <tr key={t.id}>
                      <td>
                        <div className="row">
                          <span className="tx-icon">{amt >= 0 ? <ArrowDownLeft size={16} color="var(--green)" /> : <ArrowUpRight size={16} color="var(--red)" />}</span>
                          <span style={{ textTransform: 'capitalize' }}>{t.description || String(t.type).replaceAll('_', ' ')}</span>
                        </div>
                      </td>
                      <td className="muted">{shortDate(t.created_at)}</td>
                      <td><StatusBadge value={t.type} /></td>
                      <td className={`num ${amt >= 0 ? 'pos' : 'neg'}`}><strong>{amt >= 0 ? '+' : '−'}{money(Math.abs(amt))}</strong></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState title="No transactions yet" icon={<Receipt size={22} />}>Deposit funds to get started.</EmptyState>
        )}
      </div>
    </div>
  );
}
