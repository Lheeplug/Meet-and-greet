'use client';
import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Loader2, CheckCircle2, AlertCircle, Info, Landmark } from 'lucide-react';
import { PageHeader } from '@/components/ui';

export default function Deposit() {
  const [methods, setMethods] = useState<any[]>([]), [method, setMethod] = useState(''), [amount, setAmount] = useState(''), [reference, setReference] = useState(''), [note, setNote] = useState(''), [msg, setMsg] = useState(''), [ok, setOk] = useState(false), [busy, setBusy] = useState(false), [loaded, setLoaded] = useState(false);
  useEffect(() => { createClient().from('payment_methods').select('*').eq('active', true).then(({ data }) => { setMethods(data || []); if (data?.[0]) setMethod(data[0].id); setLoaded(true); }); }, []);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setMsg(''); setBusy(true);
    const res = await fetch('/api/deposits', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ payment_method_id: method, amount: Number(amount), reference, note }) });
    const j = await res.json();
    setOk(res.ok);
    setMsg(res.ok ? `Deposit submitted. Reference: ${j.deposit.id}` : (j.error || 'Unable to submit'));
    setBusy(false);
  }
  const selected = methods.find(m => m.id === method);
  return (
    <div className="stack">
      <PageHeader eyebrow="Wallet" title="Deposit funds">Submit your payment details and an administrator will review and credit your wallet.</PageHeader>
      <div className="split">
        <div className="card fade-in">
          <form className="form" onSubmit={submit}>
            <div className="field"><label className="label" htmlFor="amount">Amount</label>
              <div className="input-prefix"><span>$</span><input id="amount" className="input" type="number" min="1" step="0.01" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value)} required /></div></div>
            <div className="field"><label className="label" htmlFor="method">Payment method</label>
              <select id="method" className="select" value={method} onChange={e => setMethod(e.target.value)} required>{methods.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}</select></div>
            <div className="field"><label className="label" htmlFor="ref">Payment reference</label>
              <input id="ref" className="input" placeholder="Transaction ID or receipt number" value={reference} onChange={e => setReference(e.target.value)} required /></div>
            <div className="field"><label className="label" htmlFor="note">Note <span className="faint">(optional)</span></label>
              <textarea id="note" className="textarea" placeholder="Anything the reviewer should know" value={note} onChange={e => setNote(e.target.value)} /></div>
            {loaded && methods.length === 0 && <div className="notice info" role="status"><Info size={16} style={{ flex: 'none', marginTop: 2 }} /><span>No payment methods are available right now. Please check back soon.</span></div>}
            {msg && <div className={`notice ${ok ? 'success' : 'error'}`} role="status">{ok ? <CheckCircle2 size={16} style={{ flex: 'none', marginTop: 2 }} /> : <AlertCircle size={16} style={{ flex: 'none', marginTop: 2 }} />}<span style={{ wordBreak: 'break-word' }}>{msg}</span></div>}
            <button className="btn primary lg" disabled={busy || !methods.length}>{busy ? <><Loader2 size={16} className="spin" />Submitting…</> : 'Submit deposit'}</button>
          </form>
        </div>
        <div className="stack">
          <div className="card fade-in">
            <div className="row" style={{ marginBottom: 14 }}><div className="icon-box"><Landmark size={19} /></div><h3 style={{ fontSize: 16 }}>Payment instructions</h3></div>
            {selected ? <p className="muted" style={{ whiteSpace: 'pre-wrap' }}>{selected.instructions}</p> : <p className="faint">Select a payment method to see how to pay.</p>}
          </div>
          <div className="notice info"><Info size={16} style={{ flex: 'none', marginTop: 2 }} /><span>Funds appear in your wallet once an administrator approves your deposit.</span></div>
        </div>
      </div>
    </div>
  );
}
