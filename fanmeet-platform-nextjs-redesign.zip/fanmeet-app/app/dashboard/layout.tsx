import { getProfile } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { Sidebar, type SideLink } from '@/components/sidebar';

const links: SideLink[] = [
  { href: '/dashboard', label: 'Overview', icon: 'overview', exact: true },
  { href: '/dashboard/deposit', label: 'Deposit', icon: 'deposit' },
  { href: '/dashboard/packages', label: 'Experiences', icon: 'experiences' },
  { href: '/dashboard/bookings', label: 'Bookings', icon: 'bookings' },
];

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const p = await getProfile();
  if (!p) redirect('/auth/sign-in');
  return (
    <main className="shell">
      <div className="container shell-grid">
        <Sidebar title="Fan account" name={p.full_name || ''} email={p.email || ''} links={links} />
        <section style={{ minWidth: 0 }}>{children}</section>
      </div>
    </main>
  );
}
