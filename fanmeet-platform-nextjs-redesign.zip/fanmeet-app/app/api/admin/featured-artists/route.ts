import { createClient } from '@/lib/supabase/server'; import { NextResponse } from 'next/server';
async function admin(){const s=await createClient();const {data:{user}}=await s.auth.getUser();if(!user)return null;const {data:p}=await s.from('profiles').select('role').eq('id',user.id).single();return p?.role==='admin'?s:null}
const clip=(v:unknown,n:number)=>String(v??'').trim().slice(0,n);
const kindOf=(k:unknown)=>k==='fan_club'?'fan_club':'meet_greet';
const kindName=(k:string)=>k==='fan_club'?'Fan Club':'Meet & Greet';
const bad=(m:string,status=400)=>NextResponse.json({error:m},{status});
// Each featured artist is backed by a row in `packages`, so booking reuses the existing create_booking() wallet function unchanged.
export async function GET(){const s=await admin();if(!s)return bad('Forbidden',403);const {data,error}=await s.from('featured_artists').select('*,packages(price)').order('sort_order').order('created_at',{ascending:false});if(error)return bad(error.message);return NextResponse.json((data||[]).map((a:any)=>{const pkg=Array.isArray(a.packages)?a.packages[0]:a.packages;const {packages:_p,...rest}=a;return {...rest,price:pkg?Number(pkg.price):null}}))}
export async function POST(req:Request){const s=await admin();if(!s)return bad('Forbidden',403);const b=await req.json();const name=clip(b.name,120);if(!name)return bad('Name is required');const price=Number(b.price);if(!Number.isFinite(price)||price<=0)return bad('Enter a price greater than 0');const kind=kindOf(b.kind);const tagline=clip(b.tagline,200);
const {data:pkg,error:pe}=await s.from('packages').insert({name:`${name} — ${kindName(kind)}`,description:tagline,price,kind,artist_name:name,active:true}).select().single();if(pe)return bad(pe.message);
const {data,error}=await s.from('featured_artists').insert({name,tagline,image_url:clip(b.image_url,500)||null,kind,package_id:pkg.id,sort_order:Number.isFinite(Number(b.sort_order))?Number(b.sort_order):0,active:true}).select().single();
if(error){await s.from('packages').delete().eq('id',pkg.id);return bad(error.message)}
return NextResponse.json({...data,price})}
export async function PATCH(req:Request){const s=await admin();if(!s)return bad('Forbidden',403);const b=await req.json();const {data:cur,error:ce}=await s.from('featured_artists').select('*').eq('id',b.id).single();if(ce||!cur)return bad('Artist not found',404);
const patch:Record<string,unknown>={};const pp:Record<string,unknown>={};
if(typeof b.active==='boolean'){patch.active=b.active;pp.active=b.active}
if(b.name!==undefined){patch.name=clip(b.name,120);pp.artist_name=patch.name}
if(b.tagline!==undefined){patch.tagline=clip(b.tagline,200);pp.description=patch.tagline}
if(b.image_url!==undefined)patch.image_url=clip(b.image_url,500)||null;
if(b.kind!==undefined){patch.kind=kindOf(b.kind);pp.kind=patch.kind}
if(b.sort_order!==undefined&&Number.isFinite(Number(b.sort_order)))patch.sort_order=Number(b.sort_order);
if(b.price!==undefined){const price=Number(b.price);if(!Number.isFinite(price)||price<=0)return bad('Enter a price greater than 0');pp.price=price}
if(!cur.package_id&&pp.price!==undefined){const kind=String(patch.kind??cur.kind);const name=String(patch.name??cur.name);const {data:pkg,error:pe}=await s.from('packages').insert({name:`${name} — ${kindName(kind)}`,description:String(patch.tagline??cur.tagline??''),price:pp.price,kind,artist_name:name,active:cur.active}).select().single();if(pe)return bad(pe.message);patch.package_id=pkg.id}
else if(cur.package_id&&Object.keys(pp).length){const {error:ue}=await s.from('packages').update(pp).eq('id',cur.package_id);if(ue)return bad(ue.message)}
if(Object.keys(patch).length){const {error}=await s.from('featured_artists').update(patch).eq('id',b.id);if(error)return bad(error.message)}
return NextResponse.json({ok:true})}
export async function DELETE(req:Request){const s=await admin();if(!s)return bad('Forbidden',403);const {id}=await req.json();const {data:cur}=await s.from('featured_artists').select('package_id').eq('id',id).single();const {error}=await s.from('featured_artists').delete().eq('id',id);if(error)return bad(error.message);if(cur?.package_id)await s.from('packages').update({active:false}).eq('id',cur.package_id);return NextResponse.json({ok:true})}
