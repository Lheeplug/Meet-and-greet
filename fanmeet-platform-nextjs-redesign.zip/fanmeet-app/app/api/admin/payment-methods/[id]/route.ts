import { createClient } from '@/lib/supabase/server'; import { NextResponse } from 'next/server';
async function admin(){const s=await createClient();const {data:{user}}=await s.auth.getUser();if(!user)return null;const {data:p}=await s.from('profiles').select('role').eq('id',user.id).single();return p?.role==='admin'?s:null}
const bad=(m:string,status=400)=>NextResponse.json({error:m},{status});
// Edit an existing payment method (name / instructions / active). Admin only; RLS enforces this again in the database.
export async function PATCH(req:Request,{params}:{params:Promise<{id:string}>}){
  const s=await admin();if(!s)return bad('Forbidden',403);
  const {id}=await params;const b=await req.json();const patch:Record<string,unknown>={};
  if(b.name!==undefined){const n=String(b.name).trim().slice(0,120);if(!n)return bad('Name is required');patch.name=n}
  if(b.instructions!==undefined){const i=String(b.instructions).trim().slice(0,2000);if(!i)return bad('Instructions are required');patch.instructions=i}
  if(typeof b.active==='boolean')patch.active=b.active;
  if(!Object.keys(patch).length)return bad('Nothing to update');
  const {data,error}=await s.from('payment_methods').update(patch).eq('id',id).select().single();
  if(error)return bad(error.message);return NextResponse.json(data)}
