import Link from 'next/link';
import { getHomepage } from '@/lib/homepage';
import { getCurrentUser } from '@/lib/auth';
import { BookExperience } from '@/components/book-experience';
import { ArrowRight, Wallet, Ticket, Crown, ShieldCheck, Zap, BadgeCheck, Sparkles } from 'lucide-react';

const features = [
  { icon: Wallet, title: 'Fan wallet', text: 'Deposit through trusted payment methods and see every transaction in a clear, real-time ledger.' },
  { icon: Ticket, title: 'Meet & Greet', text: 'Browse curated experiences and reserve your spot instantly with your wallet balance.' },
  { icon: Crown, title: 'Fan Club', text: 'Join membership packages and keep your whole booking history in one beautiful place.' },
];
const steps = [
  { t: 'Create your account', d: 'Sign up in under a minute — your secure fan wallet is created automatically.' },
  { t: 'Fund your wallet', d: 'Submit a deposit with your payment reference. Our team verifies and credits it.' },
  { t: 'Book your experience', d: 'Pick a meet & greet or membership and confirm with a single tap.' },
];

export default async function Home() {
  const { settings: h, artists } = await getHomepage();
  const user = await getCurrentUser();
  return (
    <main>
      <section className="hero">
        <div className="orb a" /><div className="orb b" />
        <div className="container hero-grid" style={{ position: 'relative' }}>
          <div className="fade-in">
            <span className="eyebrow">{h.eyebrow}</span>
            <h1 className="display">{h.title} <span className="gold-text">{h.highlight}</span></h1>
            <p className="lead">{h.subtitle}</p>
            <div className="hero-cta">
              <Link className="btn primary lg" href="/auth/sign-up">Create fan account <ArrowRight size={17} /></Link>
              <Link className="btn lg" href="/dashboard/packages">Explore experiences</Link>
            </div>
            <div className="hero-trust">
              <span><ShieldCheck size={16} />Secure by design</span>
              <span><BadgeCheck size={16} />Admin-verified deposits</span>
              <span><Zap size={16} />Instant booking</span>
            </div>
          </div>

          <div className="showcase" aria-hidden="true">
            <div className="pass p1 float">
              <div className="pass-top"><span className="badge green">Meet &amp; Greet</span><Ticket size={20} color="var(--gold)" /></div>
              <div className="pass-title">Backstage Access</div>
              <div className="pass-meta">Private session · Limited spots</div>
              <div className="pass-line" />
              <div className="row between"><span className="muted">Starting at</span><strong className="display" style={{ fontSize: 22 }}>$120.00</strong></div>
            </div>
            <div className="pass p2 float d">
              <div className="pass-top"><span className="badge blue">Fan Club</span><Crown size={20} color="var(--gold)" /></div>
              <div className="pass-title">Inner Circle Member</div>
              <div className="pass-meta">Exclusive drops · Priority booking</div>
              <div className="pass-line" />
              <div className="row between"><span className="muted">Wallet balance</span><strong className="display gold-text" style={{ fontSize: 22 }}>$480.00</strong></div>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Everything in one place</span>
            <h2 className="display">Built for fans, run with care.</h2>
            <p>A focused set of tools that make joining, funding and booking feel effortless.</p>
          </div>
          <div className="grid grid3">
            {features.map(f => (
              <div className="card hover feature" key={f.title}>
                <div className="icon-box"><f.icon size={20} /></div>
                <h3>{f.title}</h3>
                <p>{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>


      {artists.length > 0 && (
        <section className="section" style={{ paddingTop: 20 }}>
          <div className="container">
            <div className="section-head">
              <span className="eyebrow">Now booking</span>
              <h2 className="display">{h.featured_heading}</h2>
              {h.featured_subheading && <p>{h.featured_subheading}</p>}
            </div>
            <div className="grid grid3">
              {artists.map(a => (
                <div className="card flush hover artist-card" key={a.id}>
                  <div className="artist-img">
                    {a.image_url
                      // eslint-disable-next-line @next/next/no-img-element
                      ? <img src={a.image_url} alt={a.name} loading="lazy" />
                      : <span className="artist-initial display gold-text">{a.name.trim().charAt(0).toUpperCase()}</span>}
                    <span className={`badge ${a.kind === 'meet_greet' ? 'green' : 'blue'} plain artist-badge`}>{a.kind === 'meet_greet' ? 'Meet & Greet' : 'Fan Club'}</span>
                    {a.price !== null && <span className="price-tag">{a.price.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</span>}
                  </div>
                  <div className="artist-body">
                    <h3 className="display">{a.name}</h3>
                    {a.tagline && <p className="muted">{a.tagline}</p>}
                    <div className="artist-foot">
                      {a.package_id && a.price !== null
                        ? <BookExperience packageId={a.package_id} price={a.price} title={a.name} userId={user?.id ?? null} />
                        : <span className="badge plain">Coming soon</span>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="section" style={{ paddingTop: 20 }}>
        <div className="container grid grid2" style={{ gap: 56, alignItems: 'start' }}>
          <div className="section-head" style={{ marginBottom: 0 }}>
            <span className="eyebrow">How it works</span>
            <h2 className="display">From sign-up to showtime in three steps.</h2>
            <p>No clutter, no guesswork. Every step is visible so you always know where your money and bookings stand.</p>
          </div>
          <div className="steps">
            {steps.map((s, i) => (
              <div className="step" key={s.t}>
                <div className="step-n">0{i + 1}</div>
                <div><h4>{s.t}</h4><p>{s.d}</p></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="cta-band">
            <span className="eyebrow">Join FanMeet</span>
            <h2 className="display" style={{ marginTop: 16 }}>Your next unforgettable moment starts here.</h2>
            <p>Create your free account and explore the latest experiences.</p>
            <Link className="btn primary lg" href="/auth/sign-up"><Sparkles size={17} />Get started free</Link>
          </div>
        </div>
      </section>
    </main>
  );
}
