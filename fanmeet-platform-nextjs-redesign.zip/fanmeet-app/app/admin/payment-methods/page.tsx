'use client';
import { useEffect, useState } from 'react';
import { Loader2, Plus, CreditCard, Pencil, AlertCircle, CheckCircle2 } from 'lucide-react';
import { PageHeader, EmptyState } from '@/components/ui';

const json = { 'Content-Type': 'application/json' };

function MethodCard({ m, onChanged, onSaved }: { m: any; onChanged: () => void; onSaved: () => void }) {
  const [editing, setEditing] = useState(false), [name, setName] = useState(m.name), [instr, setInstr] = useState(m.instructions), [busy, setBusy] = useState(false), [err, setErr] = useState('');
  function start() { setName(m.name); setInstr(m.instructions); setErr(''); setEditing(true); }
  async function save(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setErr('');
    const r = await fetch(`/api/admin/payment-methods/${m.id}`, { method: 'PATCH', headers: json, body: JSON.stringify({ name, instructions: instr }) });
    const j = await r.json();
    if (!r.ok) setErr(j.error || 'Failed to save'); else { setEditing(false); onSaved(); onChanged(); }
    setBusy(false);
  }
  async function toggle() { await fetch('/api/admin/payment-methods', { method: 'PATCH', headers: json, body: JSON.stringify({ id: m.id, active: !m.active }) }); onChanged(); }

  if (editing) {
    return (
      <div className="card fade-in" style={{ padding: 20, borderColor: 'rgba(52,240,168,.3)' }}>
        <form className="form" onSubmit={save}>
          <div className="field"><label className="label" htmlFor={`n-${m.id}`}>Method name</label><input id={`n-${m.id}`} className="input" value={name} onChange={e => setName(e.target.value)} required /></div>
          <div className="field"><label className="label" htmlFor={`i-${m.id}`}>Instructions shown to fans</label><textarea id={`i-${m.id}`} className="textarea" value={instr} onChange={e => setInstr(e.target.value)} required /></div>
          {err && <div className="notice error" role="alert"><AlertCircle size={16} style={{ flex: 'none', marginTop: 2 }} />{err}</div>}
          <div className="row" style={{ gap: 8 }}>
            <button className="btn primary sm" disabled={busy}>{busy ? <Loader2 size={14} className="spin" /> : null}Save changes</button>
            <button type="button" className="btn sm" onClick={() => setEditing(false)} disabled={busy}>Cancel</button>
          </div>
        </form>
      </div>
    );
  }
  return (
    <div className="card hover fade-in" style={{ padding: 20 }}>
      <div className="row between" style={{ alignItems: 'flex-start' }}>
        <div className="row" style={{ alignItems: 'flex-start' }}>
          <div className="icon-box"><CreditCard size={19} /></div>
          <div><strong style={{ fontSize: 16 }}>{m.name}</strong><div style={{ marginTop: 4 }}><span className={`badge ${m.active ? 'green' : ''}`}>{m.active ? 'Active' : 'Disabled'}</span></div></div>
        </div>
        <div className="row" style={{ gap: 10 }}>
          <button type="button" className="btn sm" onClick={start} aria-label={`Edit ${m.name}`}><Pencil size={14} />Edit</button>
          <button type="button" className={`toggle${m.active ? ' on' : ''}`} role="switch" aria-checked={m.active} aria-label={`${m.active ? 'Disable' : 'Enable'} ${m.name}`} onClick={toggle} />
        </div>
      </div>
      <p className="muted" style={{ marginTop: 14, whiteSpace: 'pre-wrap' }}>{m.instructions}</p>
    </div>
  );
}

export default function PaymentMethods() {
  const [rows, setRows] = useState<any[]>([]), [form, setForm] = useState({ name: '', instructions: '' }), [busy, setBusy] = useState(false), [saved, setSaved] = useState(false);
  async function load() { const r = await fetch('/api/admin/payment-methods'); const j = await r.json(); setRows(Array.isArray(j) ? j : []); }
  useEffect(() => { load(); }, []);
  async function add(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    await fetch('/api/admin/payment-methods', { method: 'POST', headers: json, body: JSON.stringify(form) });
    setForm({ name: '', instructions: '' }); await load(); setBusy(false);
  }
  return (
    <div className="stack">
      <PageHeader eyebrow="Configuration" title="Payment methods">Add, edit or switch off the payment options fans see when depositing.</PageHeader>
      {saved && <div className="notice success" role="status"><CheckCircle2 size={16} style={{ flex: 'none', marginTop: 2 }} />Changes saved. Fans see the updated details straight away.</div>}
      <div className="split even">
        <div className="card fade-in">
          <h3 style={{ marginBottom: 18, fontSize: 17 }}>New method</h3>
          <form className="form" onSubmit={add}>
            <div className="field"><label className="label" htmlFor="mn">Method name</label><input id="mn" className="input" placeholder="e.g. Bank transfer" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required /></div>
            <div className="field"><label className="label" htmlFor="mi">Instructions shown to fans</label><textarea id="mi" className="textarea" placeholder="Account details and how to pay" value={form.instructions} onChange={e => setForm({ ...form, instructions: e.target.value })} required /></div>
            <button className="btn primary" disabled={busy}>{busy ? <Loader2 size={16} className="spin" /> : <Plus size={16} />}Add method</button>
          </form>
        </div>
        <div className="stack">
          {rows.length ? rows.map(m => <MethodCard key={m.id} m={m} onChanged={load} onSaved={() => { setSaved(true); setTimeout(() => setSaved(false), 4000); }} />) : <div className="card"><EmptyState title="No payment methods" icon={<CreditCard size={22} />}>Add one so fans can deposit.</EmptyState></div>}
        </div>
      </div>
    </div>
  );
}
