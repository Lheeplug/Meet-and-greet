import Link from 'next/link';
import { Users, Clock, CalendarCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/server';
import { PageHeader, EmptyState, money, shortDate } from '@/components/ui';

export default async function Admin() {
  const s = await createClient();
  const [{ count: users }, { count: deposits }, { count: bookings }, { data: pending }] = await Promise.all([
    s.from('profiles').select('*', { count: 'exact', head: true }),
    s.from('deposits').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
    s.from('bookings').select('*', { count: 'exact', head: true }),
    s.from('deposits').select('*').eq('status', 'pending').order('created_at', { ascending: false }).limit(5),
  ]);
  const stats = [
    { label: 'Total users', value: users || 0, icon: Users, cls: 'blue', sub: 'Registered accounts' },
    { label: 'Pending deposits', value: deposits || 0, icon: Clock, cls: 'amber', sub: 'Awaiting review' },
    { label: 'Bookings', value: bookings || 0, icon: CalendarCheck, cls: 'green', sub: 'All time' },
  ];
  return (
    <div className="stack">
      <PageHeader eyebrow="Control center" title="Admin dashboard" action={<Link href="/admin/deposits" className="btn primary">Review deposits <ArrowRight size={16} /></Link>}>
        Monitor activity and keep wallet operations moving.
      </PageHeader>
      <div className="grid grid3 fade-in">
        {stats.map(x => (
          <div className="card" key={x.label}>
            <div className="stat-label"><span>{x.label}</span><span className={`icon-box ${x.cls}`}><x.icon size={19} /></span></div>
            <div className="stat">{x.value}</div>
            <div className="stat-sub">{x.sub}</div>
          </div>
        ))}
      </div>
      <div className="card flush fade-in">
        <div className="card-head"><h3>Pending deposits</h3><Link href="/admin/deposits" className="btn sm ghost">View all</Link></div>
        {pending?.length ? (
          <div className="table-wrap">
            <table className="table">
              <thead><tr><th>Reference</th><th>Submitted</th><th className="num">Amount</th><th /></tr></thead>
              <tbody>
                {pending.map((d: any) => (
                  <tr key={d.id}>
                    <td className="mono">{d.reference}</td>
                    <td className="muted">{shortDate(d.created_at)}</td>
                    <td className="num"><strong>{money(d.amount)}</strong></td>
                    <td className="num"><Link href="/admin/deposits" className="btn sm">Review</Link></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState title="All caught up" icon={<CheckCircle2 size={22} />}>No deposits are waiting for review.</EmptyState>
        )}
      </div>
    </div>
  );
}
