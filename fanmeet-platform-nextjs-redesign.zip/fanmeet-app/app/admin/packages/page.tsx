'use client';
import { useEffect, useState } from 'react';
import { Loader2, Plus, Ticket, Crown, User, CheckCircle2, AlertCircle } from 'lucide-react';
import { PageHeader, EmptyState, money, kindLabel } from '@/components/ui';

const blank = { name: '', description: '', price: '', kind: 'meet_greet', artist_name: '' };

export default function Packages() {
  const [rows, setRows] = useState<any[]>([]), [form, setForm] = useState(blank), [msg, setMsg] = useState(''), [ok, setOk] = useState(false), [busy, setBusy] = useState(false);
  async function load() { const r = await fetch('/api/admin/packages'); const j = await r.json(); setRows(Array.isArray(j) ? j : []); }
  useEffect(() => { load(); }, []);
  async function add(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    const r = await fetch('/api/admin/packages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...form, price: Number(form.price) }) });
    const j = await r.json();
    setOk(r.ok); setMsg(r.ok ? 'Package created' : j.error);
    if (r.ok) { setForm(blank); load(); }
    setBusy(false);
  }
  return (
    <div className="stack">
      <PageHeader eyebrow="Catalog" title="Packages">Create and manage the experiences fans can book.</PageHeader>
      <div className="split" style={{ gridTemplateColumns: 'minmax(0,1fr) minmax(0,1.1fr)' }}>
        <div className="card fade-in">
          <h3 style={{ marginBottom: 18, fontSize: 17 }}>New package</h3>
          <form className="form" onSubmit={add}>
            <div className="field"><label className="label" htmlFor="pn">Package name</label><input id="pn" className="input" placeholder="e.g. Backstage Access" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required /></div>
            <div className="field"><label className="label" htmlFor="pa">Artist name</label><input id="pa" className="input" placeholder="Artist or group" value={form.artist_name} onChange={e => setForm({ ...form, artist_name: e.target.value })} required /></div>
            <div className="grid grid2" style={{ gap: 12 }}>
              <div className="field"><label className="label" htmlFor="pk">Type</label>
                <select id="pk" className="select" value={form.kind} onChange={e => setForm({ ...form, kind: e.target.value })}><option value="meet_greet">Meet &amp; Greet</option><option value="fan_club">Fan Club</option></select></div>
              <div className="field"><label className="label" htmlFor="pp">Price</label>
                <div className="input-prefix"><span>$</span><input id="pp" className="input" type="number" step="0.01" placeholder="0.00" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} required /></div></div>
            </div>
            <div className="field"><label className="label" htmlFor="pd">Description</label><textarea id="pd" className="textarea" placeholder="What does the fan get?" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
            {msg && <div className={`notice ${ok ? 'success' : 'error'}`} role="status">{ok ? <CheckCircle2 size={16} style={{ flex: 'none', marginTop: 2 }} /> : <AlertCircle size={16} style={{ flex: 'none', marginTop: 2 }} />}{msg}</div>}
            <button className="btn primary" disabled={busy}>{busy ? <Loader2 size={16} className="spin" /> : <Plus size={16} />}Add package</button>
          </form>
        </div>
        <div className="stack">
          {rows.length ? rows.map(p => {
            const mg = p.kind === 'meet_greet';
            return (
              <div className="card hover fade-in" key={p.id} style={{ padding: 20 }}>
                <div className="row between" style={{ alignItems: 'flex-start' }}>
                  <div className="row" style={{ alignItems: 'flex-start' }}>
                    <div className={`icon-box ${mg ? '' : 'blue'}`}>{mg ? <Ticket size={20} /> : <Crown size={20} />}</div>
                    <div><strong style={{ fontSize: 16 }}>{p.name}</strong>
                      <div className="row muted" style={{ fontSize: 13, marginTop: 4, gap: 6 }}><User size={13} />{p.artist_name} · {kindLabel(p.kind)}</div></div>
                  </div>
                  <div className="display" style={{ fontSize: 22 }}>{money(p.price)}</div>
                </div>
              </div>
            );
          }) : <div className="card"><EmptyState title="No packages yet" icon={<Ticket size={22} />}>Create your first package to get started.</EmptyState></div>}
        </div>
      </div>
    </div>
  );
}
