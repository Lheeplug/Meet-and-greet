'use client';
import { useEffect, useState } from 'react';
import { Check, X, Loader2, Landmark } from 'lucide-react';
import { PageHeader, StatusBadge, EmptyState, money, shortDate } from '@/components/ui';

const filters = ['all', 'pending', 'approved', 'rejected'] as const;

export default function AdminDeposits() {
  const [rows, setRows] = useState<any[]>([]), [msg, setMsg] = useState(''), [loading, setLoading] = useState(true), [filter, setFilter] = useState<(typeof filters)[number]>('pending'), [working, setWorking] = useState('');
  async function load() { const r = await fetch('/api/admin/deposits'); const j = await r.json(); setRows(Array.isArray(j) ? j : []); setLoading(false); }
  useEffect(() => { load(); }, []);
  async function act(id: string, action: 'approve' | 'reject') {
    setMsg(''); setWorking(id + action);
    const r = await fetch('/api/admin/deposits', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, action }) });
    const j = await r.json();
    setMsg(r.ok ? (action === 'approve' ? 'Deposit approved' : 'Deposit rejected') : j.error || 'Failed');
    setWorking(''); load();
  }
  const shown = filter === 'all' ? rows : rows.filter(d => d.status === filter);
  const failed = msg === 'Failed' || (msg && !msg.startsWith('Deposit'));
  return (
    <div className="stack">
      <PageHeader eyebrow="Wallet operations" title="Deposits" action={
        <div className="tabs" role="tablist">
          {filters.map(f => <button key={f} role="tab" aria-selected={filter === f} className={`tab${filter === f ? ' on' : ''}`} onClick={() => setFilter(f)} style={{ textTransform: 'capitalize' }}>{f}</button>)}
        </div>
      }>Review payment submissions and credit fan wallets.</PageHeader>
      {msg && <div className={`notice ${failed ? 'error' : 'success'}`} role="status">{msg}</div>}
      <div className="card flush fade-in">
        {loading ? (
          <div style={{ padding: 24, display: 'grid', gap: 16 }}>{[0, 1, 2].map(i => <div key={i} className="skeleton" style={{ height: 18 }} />)}</div>
        ) : shown.length ? (
          <div className="table-wrap">
            <table className="table">
              <thead><tr><th>Reference</th><th>Submitted</th><th className="num">Amount</th><th>Status</th><th className="num">Action</th></tr></thead>
              <tbody>
                {shown.map(d => (
                  <tr key={d.id}>
                    <td className="mono">{d.reference}</td>
                    <td className="muted">{shortDate(d.created_at)}</td>
                    <td className="num"><strong>{money(d.amount)}</strong></td>
                    <td><StatusBadge value={d.status} /></td>
                    <td className="num">
                      {d.status === 'pending' && (
                        <div className="row" style={{ justifyContent: 'flex-end', gap: 8 }}>
                          <button className="btn sm success" disabled={!!working} onClick={() => act(d.id, 'approve')}>{working === d.id + 'approve' ? <Loader2 size={14} className="spin" /> : <Check size={14} />}Approve</button>
                          <button className="btn sm danger" disabled={!!working} onClick={() => act(d.id, 'reject')}>{working === d.id + 'reject' ? <Loader2 size={14} className="spin" /> : <X size={14} />}Reject</button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState title={`No ${filter === 'all' ? '' : filter + ' '}deposits`} icon={<Landmark size={22} />}>Nothing to show for this filter.</EmptyState>
        )}
      </div>
    </div>
  );
}
