import { getProfile } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { Sidebar, type SideLink } from '@/components/sidebar';

const links: SideLink[] = [
  { href: '/admin', label: 'Overview', icon: 'overview', exact: true },
  { href: '/admin/deposits', label: 'Deposits', icon: 'deposits' },
  { href: '/admin/users', label: 'Users', icon: 'users' },
  { href: '/admin/packages', label: 'Packages', icon: 'packages' },
  { href: '/admin/payment-methods', label: 'Payment methods', icon: 'methods' },
  { href: '/admin/homepage', label: 'Homepage', icon: 'homepage' },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const p = await getProfile();
  if (!p) redirect('/auth/sign-in');
  if (p.role !== 'admin') redirect('/dashboard');
  return (
    <main className="shell">
      <div className="container shell-grid">
        <Sidebar title="Admin console" name={p.full_name || 'Administrator'} email={p.email || ''} links={links} />
        <section style={{ minWidth: 0 }}>{children}</section>
      </div>
    </main>
  );
}
