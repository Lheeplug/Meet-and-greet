'use client';
import { useEffect, useState } from 'react';
import { Loader2, Plus, Trash2, Save, CheckCircle2, AlertCircle, ExternalLink, Users, Upload } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import Link from 'next/link';
import { PageHeader, EmptyState, kindLabel } from '@/components/ui';

const emptySettings = { eyebrow: '', title: '', highlight: '', subtitle: '', featured_heading: '', featured_subheading: '' };
const emptyArtist = { name: '', tagline: '', image_url: '', kind: 'meet_greet', price: '', sort_order: '0' };

function PriceEditor({ artist, onSaved }: { artist: any; onSaved: () => void }) {
  const [v, setV] = useState(artist.price != null ? String(artist.price) : ''), [busy, setBusy] = useState(false), [err, setErr] = useState('');
  async function save(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setErr('');
    const r = await fetch('/api/admin/featured-artists', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: artist.id, price: Number(v) }) });
    const j = await r.json(); if (!r.ok) setErr(j.error || 'Failed'); else onSaved(); setBusy(false);
  }
  return (
    <form onSubmit={save} className="row" style={{ marginTop: 12, gap: 8, flexWrap: 'wrap' }}>
      <div className="input-prefix" style={{ width: 130 }}><span>$</span><input className="input" style={{ padding: '8px 10px 8px 28px' }} type="number" min="0.01" step="0.01" placeholder="Set price" aria-label={`Price for ${artist.name}`} value={v} onChange={e => setV(e.target.value)} required /></div>
      <button className="btn sm" disabled={busy}>{busy ? <Loader2 size={14} className="spin" /> : 'Update price'}</button>
      {err && <span className="neg" style={{ fontSize: 12.5 }}>{err}</span>}
    </form>
  );
}

export default function AdminHomepage() {
  const [settings, setSettings] = useState(emptySettings), [artists, setArtists] = useState<any[]>([]), [form, setForm] = useState(emptyArtist);
  const [sMsg, setSMsg] = useState<{ ok: boolean; text: string } | null>(null), [aMsg, setAMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [savingS, setSavingS] = useState(false), [savingA, setSavingA] = useState(false);
  const [logo, setLogo] = useState(''), [logoBusy, setLogoBusy] = useState(false), [logoMsg, setLogoMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function loadSettings() { const r = await fetch('/api/admin/homepage'); const j = await r.json(); if (r.ok) setLogo(j.logo_url || ''); if (r.ok) setSettings({ ...emptySettings, ...Object.fromEntries(Object.entries(j).filter(([k]) => k in emptySettings)) } as typeof emptySettings); }
  async function loadArtists() { const r = await fetch('/api/admin/featured-artists'); const j = await r.json(); if (!r.ok) setAMsg({ ok: false, text: j.error || 'Unable to load artists. Have you run supabase/homepage.sql?' }); setArtists(Array.isArray(j) ? j : []); }
  useEffect(() => { loadSettings(); loadArtists(); }, []);

  async function saveLogoUrl(url: string) {
    const r = await fetch('/api/admin/homepage', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ logo_url: url }) });
    const j = await r.json(); return { ok: r.ok, error: j.error as string | undefined };
  }
  async function uploadLogo(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; e.target.value = '';
    if (!file) return; setLogoMsg(null);
    if (!/^image\/(png|jpe?g|webp|svg\+xml|gif)$/.test(file.type)) { setLogoMsg({ ok: false, text: 'Use a PNG, JPG, WebP, SVG or GIF image' }); return; }
    if (file.size > 2 * 1024 * 1024) { setLogoMsg({ ok: false, text: 'Image must be 2 MB or smaller' }); return; }
    setLogoBusy(true);
    const ext = (file.name.split('.').pop() || 'png').toLowerCase().replace(/[^a-z0-9]/g, '') || 'png';
    const sb = createClient(); const path = `logo-${Date.now()}.${ext}`;
    const { error } = await sb.storage.from('site-assets').upload(path, file, { contentType: file.type, cacheControl: '3600' });
    if (error) { setLogoMsg({ ok: false, text: error.message + ' (have you run supabase/homepage.sql?)' }); setLogoBusy(false); return; }
    const url = sb.storage.from('site-assets').getPublicUrl(path).data.publicUrl;
    const res = await saveLogoUrl(url);
    if (res.ok) setLogo(url);
    setLogoMsg({ ok: res.ok, text: res.ok ? 'Logo updated. It now replaces the icon and name in the header and footer.' : res.error || 'Failed to save logo' });
    setLogoBusy(false);
  }
  async function removeLogo() {
    setLogoBusy(true); setLogoMsg(null);
    const res = await saveLogoUrl('');
    if (res.ok) setLogo('');
    setLogoMsg({ ok: res.ok, text: res.ok ? 'Logo removed. The default icon and FANMEET name are shown again.' : res.error || 'Failed to remove logo' });
    setLogoBusy(false);
  }

  async function saveSettings(e: React.FormEvent) {
    e.preventDefault(); setSavingS(true); setSMsg(null);
    const r = await fetch('/api/admin/homepage', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(settings) });
    const j = await r.json(); setSMsg({ ok: r.ok, text: r.ok ? 'Homepage text saved' : j.error || 'Failed to save' }); setSavingS(false);
  }
  async function addArtist(e: React.FormEvent) {
    e.preventDefault(); setSavingA(true); setAMsg(null);
    const r = await fetch('/api/admin/featured-artists', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...form, price: Number(form.price), sort_order: Number(form.sort_order) || 0 }) });
    const j = await r.json(); setAMsg({ ok: r.ok, text: r.ok ? 'Artist added to homepage' : j.error || 'Failed to add' });
    if (r.ok) { setForm(emptyArtist); loadArtists(); } setSavingA(false);
  }
  async function toggle(id: string, active: boolean) { await fetch('/api/admin/featured-artists', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, active }) }); loadArtists(); }
  async function remove(id: string, name: string) { if (!confirm(`Remove ${name} from the homepage?`)) return; await fetch('/api/admin/featured-artists', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) }); loadArtists(); }

  const set = (k: keyof typeof emptySettings) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setSettings({ ...settings, [k]: e.target.value });
  const note = (m: { ok: boolean; text: string } | null) => m && <div className={`notice ${m.ok ? 'success' : 'error'}`} role="status">{m.ok ? <CheckCircle2 size={16} style={{ flex: 'none', marginTop: 2 }} /> : <AlertCircle size={16} style={{ flex: 'none', marginTop: 2 }} />}{m.text}</div>;

  return (
    <div className="stack">
      <PageHeader eyebrow="Content" title="Homepage" action={<Link href="/" target="_blank" className="btn">View homepage <ExternalLink size={15} /></Link>}>
        Control the headline and which artists are featured on the public homepage.
      </PageHeader>

      <div className="card fade-in">
        <h3 style={{ marginBottom: 18, fontSize: 17 }}>Site logo</h3>
        <div className="row" style={{ gap: 18, flexWrap: 'wrap', alignItems: 'center' }}>
          <div className="logo-preview">{logo ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={logo} alt="Current site logo" /> : 'No logo set'}</div>
          <div style={{ display: 'grid', gap: 10, justifyItems: 'start' }}>
            <label className="btn primary" style={{ cursor: logoBusy ? 'not-allowed' : 'pointer', opacity: logoBusy ? .6 : 1 }}>
              {logoBusy ? <Loader2 size={16} className="spin" /> : <Upload size={16} />}{logo ? 'Replace logo' : 'Upload logo'}
              <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml,image/gif" onChange={uploadLogo} disabled={logoBusy} hidden />
            </label>
            {logo && <button type="button" className="btn sm danger" onClick={removeLogo} disabled={logoBusy}><Trash2 size={14} />Remove logo</button>}
          </div>
        </div>
        <p className="faint" style={{ fontSize: 12.5, margin: '14px 0' }}>PNG, JPG, WebP, SVG or GIF, up to 2 MB. Replaces both the icon and the FANMEET name in the header and footer, so include your brand name in the image if you want it shown. A wide logo with a transparent background works best.</p>
        {note(logoMsg)}
      </div>

      <div className="card fade-in">
        <h3 style={{ marginBottom: 18, fontSize: 17 }}>Hero &amp; section text</h3>
        <form className="form" onSubmit={saveSettings}>
          <div className="field"><label className="label" htmlFor="h-eyebrow">Small label above headline</label><input id="h-eyebrow" className="input" value={settings.eyebrow} onChange={set('eyebrow')} maxLength={120} /></div>
          <div className="grid grid2" style={{ gap: 12 }}>
            <div className="field"><label className="label" htmlFor="h-title">Headline</label><input id="h-title" className="input" value={settings.title} onChange={set('title')} maxLength={120} /></div>
            <div className="field"><label className="label" htmlFor="h-hl">Highlighted words (gold)</label><input id="h-hl" className="input" value={settings.highlight} onChange={set('highlight')} maxLength={120} /></div>
          </div>
          <div className="field"><label className="label" htmlFor="h-sub">Subtitle</label><textarea id="h-sub" className="textarea" value={settings.subtitle} onChange={set('subtitle')} maxLength={500} /></div>
          <div className="grid grid2" style={{ gap: 12 }}>
            <div className="field"><label className="label" htmlFor="h-fh">Featured section heading</label><input id="h-fh" className="input" value={settings.featured_heading} onChange={set('featured_heading')} maxLength={120} /></div>
            <div className="field"><label className="label" htmlFor="h-fs">Featured section subheading</label><input id="h-fs" className="input" value={settings.featured_subheading} onChange={set('featured_subheading')} maxLength={200} /></div>
          </div>
          {note(sMsg)}
          <div><button className="btn primary" disabled={savingS}>{savingS ? <Loader2 size={16} className="spin" /> : <Save size={16} />}Save text</button></div>
        </form>
      </div>

      <div className="split even">
        <div className="card fade-in">
          <h3 style={{ marginBottom: 18, fontSize: 17 }}>Add featured artist</h3>
          <form className="form" onSubmit={addArtist}>
            <div className="field"><label className="label" htmlFor="a-name">Artist name</label><input id="a-name" className="input" placeholder="Artist or group" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required /></div>
            <div className="field"><label className="label" htmlFor="a-tag">Tagline</label><input id="a-tag" className="input" placeholder="e.g. Private backstage session this November" value={form.tagline} onChange={e => setForm({ ...form, tagline: e.target.value })} /></div>
            <div className="field"><label className="label" htmlFor="a-img">Image URL <span className="faint">(optional)</span></label><input id="a-img" className="input" type="url" placeholder="https://…/artist.jpg" value={form.image_url} onChange={e => setForm({ ...form, image_url: e.target.value })} /></div>
            <div className="field"><label className="label" htmlFor="a-price">Price (charged from the fan&apos;s wallet)</label><div className="input-prefix"><span>$</span><input id="a-price" className="input" type="number" min="0.01" step="0.01" placeholder="0.00" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} required /></div></div>
            <div className="grid grid2" style={{ gap: 12 }}>
              <div className="field"><label className="label" htmlFor="a-kind">Type</label><select id="a-kind" className="select" value={form.kind} onChange={e => setForm({ ...form, kind: e.target.value })}><option value="meet_greet">Meet &amp; Greet</option><option value="fan_club">Fan Club</option></select></div>
              <div className="field"><label className="label" htmlFor="a-ord">Display order</label><input id="a-ord" className="input" type="number" value={form.sort_order} onChange={e => setForm({ ...form, sort_order: e.target.value })} /></div>
            </div>
            {note(aMsg)}
            <button className="btn primary" disabled={savingA}>{savingA ? <Loader2 size={16} className="spin" /> : <Plus size={16} />}Add to homepage</button>
          </form>
        </div>

        <div className="stack">
          {artists.length ? artists.map(a => (
            <div className="card hover fade-in" key={a.id} style={{ padding: 18 }}>
              <div className="row between" style={{ alignItems: 'flex-start' }}>
                <div className="row" style={{ alignItems: 'flex-start' }}>
                  <div className="thumb">{a.image_url ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={a.image_url} alt="" /> : a.name.charAt(0).toUpperCase()}</div>
                  <div><strong style={{ fontSize: 16 }}>{a.name}</strong>
                    <div className="muted" style={{ fontSize: 13, marginTop: 3 }}>{a.tagline || '—'}</div>
                    <div className="row" style={{ marginTop: 8, gap: 8 }}><span className={`badge ${a.kind === 'meet_greet' ? 'green' : 'blue'} plain`}>{kindLabel(a.kind)}</span><span className={`badge ${a.active ? 'green' : ''}`}>{a.active ? 'Shown' : 'Hidden'}</span></div>
                    <PriceEditor artist={a} onSaved={loadArtists} /></div>
                </div>
                <div className="row" style={{ gap: 8 }}>
                  <button type="button" className={`toggle${a.active ? ' on' : ''}`} role="switch" aria-checked={a.active} aria-label={`${a.active ? 'Hide' : 'Show'} ${a.name} on homepage`} onClick={() => toggle(a.id, !a.active)} />
                  <button type="button" className="btn sm danger" aria-label={`Remove ${a.name}`} onClick={() => remove(a.id, a.name)}><Trash2 size={14} /></button>
                </div>
              </div>
            </div>
          )) : <div className="card"><EmptyState title="No featured artists" icon={<Users size={22} />}>Add an artist and they will appear on the homepage.</EmptyState></div>}
        </div>
      </div>
    </div>
  );
}
