import { createClient } from '@/lib/supabase/server';
import { UserBalanceForm } from '@/components/user-balance-form';
import { PageHeader, StatusBadge, money } from '@/components/ui';

export default async function Users() {
  const s = await createClient();
  const { data } = await s.from('profiles').select('id,full_name,email,role,wallets(balance)').order('created_at', { ascending: false });
  return (
    <div className="stack">
      <PageHeader eyebrow="Accounts" title="Users">{data?.length || 0} registered accounts. Apply positive or negative wallet adjustments.</PageHeader>
      <div className="card flush fade-in">
        <div className="table-wrap">
          <table className="table" style={{ minWidth: 640 }}>
            <thead><tr><th>User</th><th>Role</th><th className="num">Balance</th><th className="num">Adjust wallet</th></tr></thead>
            <tbody>
              {data?.map((u: any) => {
                const init = (u.full_name || u.email || '?').trim().split(/\s+/).map((x: string) => x[0]).slice(0, 2).join('').toUpperCase();
                return (
                  <tr key={u.id}>
                    <td><div className="row"><div className="avatar">{init}</div><div><div style={{ fontWeight: 600 }}>{u.full_name || '—'}</div><div className="faint" style={{ fontSize: 12.5 }}>{u.email}</div></div></div></td>
                    <td><StatusBadge value={u.role} /></td>
                    <td className="num"><strong>{money(Array.isArray(u.wallets) ? u.wallets[0]?.balance : u.wallets?.balance)}</strong></td>
                    <td><UserBalanceForm userId={u.id} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
