'use client';
import { useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';
import { Loader2, AlertCircle } from 'lucide-react';
import { AuthArt } from '@/components/auth-art';

export default function SignIn() {
  const [email, setEmail] = useState(''), [password, setPassword] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const router = useRouter();
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError('');
    const { error } = await createClient().auth.signInWithPassword({ email, password });
    if (error) setError(error.message); else { router.push('/dashboard'); router.refresh(); }
    setBusy(false);
  }
  return (
    <main className="auth">
      <AuthArt title={<>Welcome back to the <span className="gold-text">front row.</span></>} />
      <div className="auth-form-wrap">
        <div className="auth-form fade-in">
          <span className="eyebrow">Welcome back</span>
          <h1 className="display">Sign in</h1>
          <p className="sub">Access your wallet, bookings and experiences.</p>
          <form className="form" onSubmit={submit}>
            <div className="field"><label className="label" htmlFor="email">Email</label>
              <input id="email" className="input" type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required /></div>
            <div className="field"><label className="label" htmlFor="password">Password</label>
              <input id="password" className="input" type="password" autoComplete="current-password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} required /></div>
            {error && <div className="notice error" role="alert"><AlertCircle size={16} style={{ flex: 'none', marginTop: 2 }} />{error}</div>}
            <button className="btn primary lg block" disabled={busy}>{busy ? <><Loader2 size={16} className="spin" />Signing in…</> : 'Sign in'}</button>
          </form>
          <p className="auth-alt">New to FanMeet? <Link href="/auth/sign-up">Create an account</Link></p>
        </div>
      </div>
    </main>
  );
}
