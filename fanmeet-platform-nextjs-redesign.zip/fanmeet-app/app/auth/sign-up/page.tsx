'use client';
import { useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';
import { Loader2, AlertCircle, CheckCircle2 } from 'lucide-react';
import { AuthArt } from '@/components/auth-art';

export default function SignUp() {
  const [name, setName] = useState(''), [email, setEmail] = useState(''), [password, setPassword] = useState(''), [msg, setMsg] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const router = useRouter();
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setError(''); setBusy(true);
    const { data, error } = await createClient().auth.signUp({ email, password, options: { data: { full_name: name } } });
    if (error) setError(error.message); else if (data.session) { router.push('/dashboard'); router.refresh(); } else setMsg('Check your email to confirm your account.');
    setBusy(false);
  }
  return (
    <main className="auth">
      <AuthArt title={<>Become part of something <span className="gold-text">extraordinary.</span></>} />
      <div className="auth-form-wrap">
        <div className="auth-form fade-in">
          <span className="eyebrow">Become a member</span>
          <h1 className="display">Create account</h1>
          <p className="sub">Your secure fan wallet is set up automatically.</p>
          <form className="form" onSubmit={submit}>
            <div className="field"><label className="label" htmlFor="name">Full name</label>
              <input id="name" className="input" autoComplete="name" placeholder="Your name" value={name} onChange={e => setName(e.target.value)} required /></div>
            <div className="field"><label className="label" htmlFor="email">Email</label>
              <input id="email" className="input" type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required /></div>
            <div className="field"><label className="label" htmlFor="password">Password</label>
              <input id="password" className="input" type="password" minLength={8} autoComplete="new-password" placeholder="8+ characters" value={password} onChange={e => setPassword(e.target.value)} required /></div>
            {error && <div className="notice error" role="alert"><AlertCircle size={16} style={{ flex: 'none', marginTop: 2 }} />{error}</div>}
            {msg && <div className="notice success" role="status"><CheckCircle2 size={16} style={{ flex: 'none', marginTop: 2 }} />{msg}</div>}
            <button className="btn primary lg block" disabled={busy}>{busy ? <><Loader2 size={16} className="spin" />Creating…</> : 'Create account'}</button>
          </form>
          <p className="auth-alt">Already a member? <Link href="/auth/sign-in">Sign in</Link></p>
        </div>
      </div>
    </main>
  );
}
