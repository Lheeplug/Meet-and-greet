'use client';
import { useState } from 'react';
import { Loader2 } from 'lucide-react';
export function UserBalanceForm({ userId }: { userId: string }) {
  const [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    await fetch('/api/admin/users', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId, amount: Number(amount), note: 'Manual admin adjustment' }) });
    setBusy(false); location.reload();
  }
  return (
    <form onSubmit={submit} style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
      <input className="input" style={{ maxWidth: 130, padding: '9px 12px' }} type="number" step="0.01" placeholder="± amount" aria-label="Adjustment amount" value={amount} onChange={e => setAmount(e.target.value)} required />
      <button className="btn sm" disabled={busy}>{busy ? <Loader2 size={14} className="spin" /> : 'Apply'}</button>
    </form>
  );
}
