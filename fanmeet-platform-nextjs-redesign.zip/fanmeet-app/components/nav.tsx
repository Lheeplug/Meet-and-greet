import Link from 'next/link';
import { LogOut, LayoutDashboard } from 'lucide-react';
import { getProfile } from '@/lib/auth';
import { getSiteLogo } from '@/lib/homepage';
import { BrandMark } from '@/components/brand-mark';

export async function Nav() {
  const [profile, logo] = await Promise.all([getProfile(), getSiteLogo()]);
  return (
    <header className="nav">
      <div className="container nav-inner">
        <Link href="/" className="brand" aria-label="FanMeet home">
          <BrandMark logo={logo} />
        </Link>
        <nav className="navlinks" aria-label="Primary">
          <Link href="/">Home</Link>
          <Link href="/dashboard/packages">Experiences</Link>
          {profile && <Link href="/dashboard">Dashboard</Link>}
          {profile?.role === 'admin' && <Link href="/admin">Admin</Link>}
        </nav>
        <div className="nav-actions">
          {profile ? (
            <>
              <Link className="btn sm hide-sm" href="/dashboard"><LayoutDashboard size={15} />Dashboard</Link>
              <form action="/auth/sign-out" method="post">
                <button className="btn sm ghost" aria-label="Sign out"><LogOut size={15} />Sign out</button>
              </form>
            </>
          ) : (
            <>
              <Link className="btn sm ghost" href="/auth/sign-in">Sign in</Link>
              <Link className="btn sm primary" href="/auth/sign-up">Join now</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
