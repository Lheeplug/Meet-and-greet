'use client';
import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Wallet, Loader2, AlertCircle, X, Plus, LogIn } from 'lucide-react';

const fmt = (n: number) => n.toLocaleString('en-US', { style: 'currency', currency: 'USD' });

export function BookExperience({ packageId, price, title, userId, label = 'Book now' }: { packageId: string; price: number; title: string; userId: string | null; label?: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false), [mounted, setMounted] = useState(false);
  const [balance, setBalance] = useState<number | null>(null), [busy, setBusy] = useState(false), [error, setError] = useState(''), [serverShort, setServerShort] = useState(false);

  useEffect(() => setMounted(true), []);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow; document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = prev; };
  }, [open]);

  async function start() {
    if (!userId) { router.push('/auth/sign-in'); return; }
    setOpen(true); setError(''); setServerShort(false); setBalance(null);
    const { data } = await createClient().from('wallets').select('balance').eq('user_id', userId).single();
    setBalance(Number(data?.balance || 0));
  }
  async function confirm() {
    setBusy(true); setError('');
    const r = await fetch('/api/bookings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ package_id: packageId }) });
    const j = await r.json();
    if (r.ok) { router.push('/dashboard/bookings'); router.refresh(); return; }
    if (/insufficient/i.test(j.error || '')) setServerShort(true); else setError(j.error || 'Booking failed');
    setBusy(false);
  }

  const short = serverShort || (balance !== null && balance < price);
  const need = Math.max(price - (balance ?? 0), 0);

  return (
    <>
      <button className="btn primary" onClick={start}>{userId ? <><Wallet size={15} />{label}</> : <><LogIn size={15} />Sign in to book</>}</button>
      {mounted && open && createPortal(
        <div className="modal-backdrop" onClick={() => !busy && setOpen(false)}>
          <div className="modal" role="dialog" aria-modal="true" aria-labelledby="bk-title" onClick={e => e.stopPropagation()}>
            <button className="modal-x btn ghost sm" aria-label="Close" onClick={() => setOpen(false)}><X size={16} /></button>
            <span className="eyebrow">{short ? 'Wallet top-up needed' : 'Confirm booking'}</span>
            <h3 id="bk-title" className="display" style={{ fontSize: 26, margin: '12px 0 4px' }}>{title}</h3>
            {balance === null ? (
              <div style={{ padding: '28px 0', display: 'grid', placeItems: 'center' }}><Loader2 className="spin" size={22} color="var(--gold)" /></div>
            ) : (
              <>
                <div className="sum">
                  <div><span>Price</span><strong>{fmt(price)}</strong></div>
                  <div><span>Your wallet balance</span><strong className={short ? 'neg' : ''}>{fmt(balance)}</strong></div>
                  {short
                    ? <div className="total"><span>Amount needed</span><strong className="gold-text">{fmt(need)}</strong></div>
                    : <div className="total"><span>Balance after booking</span><strong>{fmt(balance - price)}</strong></div>}
                </div>
                {short ? (
                  <>
                    <div className="notice info"><AlertCircle size={16} style={{ flex: 'none', marginTop: 2 }} /><span>Your balance isn&apos;t enough for this booking. Fund your wallet with at least {fmt(need)}, then come back to book.</span></div>
                    <div className="modal-actions"><Link href="/dashboard/deposit" className="btn primary lg"><Plus size={16} />Fund wallet</Link><button className="btn lg" onClick={() => setOpen(false)}>Not now</button></div>
                  </>
                ) : (
                  <>
                    {error && <div className="notice error" role="alert"><AlertCircle size={16} style={{ flex: 'none', marginTop: 2 }} />{error}</div>}
                    <div className="modal-actions"><button className="btn primary lg" onClick={confirm} disabled={busy}>{busy ? <><Loader2 size={16} className="spin" />Processing…</> : `Pay ${fmt(price)} from wallet`}</button><button className="btn lg" onClick={() => setOpen(false)} disabled={busy}>Cancel</button></div>
                  </>
                )}
              </>
            )}
          </div>
        </div>, document.body)}
    </>
  );
}
