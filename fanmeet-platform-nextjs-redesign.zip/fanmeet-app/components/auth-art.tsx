import { Sparkles, ShieldCheck, Wallet, Ticket } from 'lucide-react';

export function AuthArt({ title }: { title: React.ReactNode }) {
  return (
    <div className="auth-art">
      <div>
        <span className="brand"><span className="brand-mark"><Sparkles size={16} strokeWidth={2.4} /></span>FANMEET</span>
        <h2 className="display" style={{ marginTop: 40 }}>{title}</h2>
      </div>
      <ul>
        <li><Wallet size={18} />A secure wallet for every fan</li>
        <li><Ticket size={18} />Book meet &amp; greets in seconds</li>
        <li><ShieldCheck size={18} />Admin-verified deposits</li>
      </ul>
    </div>
  );
}
