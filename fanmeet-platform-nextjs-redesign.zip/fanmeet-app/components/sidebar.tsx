'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard, Wallet, Ticket, CalendarCheck, Users, Package, CreditCard, Landmark, LayoutTemplate,
} from 'lucide-react';

const icons = { overview: LayoutDashboard, deposit: Wallet, experiences: Ticket, bookings: CalendarCheck, deposits: Landmark, users: Users, packages: Package, methods: CreditCard, homepage: LayoutTemplate };
export type SideIcon = keyof typeof icons;
export type SideLink = { href: string; label: string; icon: SideIcon; exact?: boolean };

export function Sidebar({ title, name, email, links }: { title: string; name: string; email: string; links: SideLink[] }) {
  const path = usePathname();
  const initials = (name || email || '?').trim().split(/\s+/).map(s => s[0]).slice(0, 2).join('').toUpperCase();
  return (
    <aside className="card sidebar" aria-label={title}>
      <div className="side-user">
        <div className="avatar">{initials}</div>
        <div><div className="nm">{name || 'Member'}</div><div className="em">{email}</div></div>
      </div>
      <div className="side-label">{title}</div>
      {links.map(l => {
        const Icon = icons[l.icon];
        const active = l.exact ? path === l.href : path === l.href || path.startsWith(l.href + '/');
        return (
          <Link key={l.href} href={l.href} className={`sideitem${active ? ' active' : ''}`} aria-current={active ? 'page' : undefined}>
            <Icon size={18} />{l.label}
          </Link>
        );
      })}
    </aside>
  );
}
