'use client';
import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
export function WalletBalance({ userId, initialBalance }: { userId: string; initialBalance: number }) {
  const [balance, setBalance] = useState(initialBalance);
  useEffect(() => {
    const supabase = createClient();
    const channel = supabase.channel(`wallet-${userId}`).on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'wallets', filter: `user_id=eq.${userId}` }, payload => { setBalance(Number((payload.new as any).balance || 0)); }).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [userId]);
  return <div className="stat">{balance.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</div>;
}
