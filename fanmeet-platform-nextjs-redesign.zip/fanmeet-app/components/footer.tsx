import Link from 'next/link';
import { ShieldCheck, Wallet, BadgeCheck } from 'lucide-react';
import { getSiteLogo } from '@/lib/homepage';
import { BrandMark } from '@/components/brand-mark';

export async function Footer() {
  const logo = await getSiteLogo();
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-brand">
            <Link href="/" className="brand" aria-label="FanMeet home"><BrandMark logo={logo} /></Link>
            <p>A premium fan-club platform for memberships, meet &amp; greets and curated experiences.</p>
          </div>
          <nav aria-label="Explore">
            <h4>Explore</h4>
            <Link href="/">Home</Link>
            <Link href="/dashboard/packages">Experiences</Link>
            <Link href="/dashboard/bookings">My bookings</Link>
          </nav>
          <nav aria-label="Account">
            <h4>Account</h4>
            <Link href="/auth/sign-in">Sign in</Link>
            <Link href="/auth/sign-up">Create account</Link>
            <Link href="/dashboard/deposit">Fund wallet</Link>
          </nav>
          <div>
            <h4>Why FanMeet</h4>
            <span><ShieldCheck size={15} />Secure by design</span>
            <span><Wallet size={15} />Wallet-based booking</span>
            <span><BadgeCheck size={15} />Admin-verified deposits</span>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} FanMeet. All rights reserved.</span>
          <span>Officially authorized fan experiences.</span>
        </div>
      </div>
    </footer>
  );
}
