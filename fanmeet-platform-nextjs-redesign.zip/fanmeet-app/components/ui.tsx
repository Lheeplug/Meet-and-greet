import type { ReactNode } from 'react';
import { Inbox } from 'lucide-react';

const tone: Record<string, string> = {
  pending: 'yellow', approved: 'green', rejected: 'red',
  confirmed: 'green', completed: 'blue', cancelled: 'red',
  deposit: 'green', booking: 'yellow', refund: 'blue', adjustment: '',
  admin: 'blue', fan: '',
};

export function StatusBadge({ value }: { value: string }) {
  return <span className={`badge ${tone[value] ?? ''}`}>{String(value).replaceAll('_', ' ')}</span>;
}

export function PageHeader({ eyebrow, title, children, action }: { eyebrow: string; title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="page-head fade-in">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1 className="display">{title}</h1>
        {children && <p>{children}</p>}
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ title, children, icon }: { title: string; children?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="empty">
      <div className="icon-box">{icon ?? <Inbox size={22} />}</div>
      <strong>{title}</strong>
      {children && <span>{children}</span>}
    </div>
  );
}

export const money = (n: number | string | null | undefined) =>
  Number(n || 0).toLocaleString('en-US', { style: 'currency', currency: 'USD' });

export const shortDate = (s?: string | null) =>
  s ? new Date(s).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—';

export const kindLabel = (k?: string | null) => (k === 'meet_greet' ? 'Meet & Greet' : k === 'fan_club' ? 'Fan Club' : '—');
