import { Sparkles } from 'lucide-react';

// With an admin-uploaded logo: shows only the logo (it replaces both the icon and the "FANMEET" name).
// Without one: shows the default icon + FANMEET wordmark.
export function BrandMark({ logo }: { logo?: string | null }) {
  if (logo) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={logo} alt="FanMeet" className="brand-logo" />;
  }
  return (
    <>
      <span className="brand-mark"><Sparkles size={16} strokeWidth={2.4} /></span>
      FANMEET
    </>
  );
}
