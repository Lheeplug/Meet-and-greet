-- FanMeet: editable homepage content + site logo. Run AFTER schema.sql in the Supabase SQL Editor.
-- Safe to re-run: every statement is idempotent.
create table if not exists public.homepage_settings(
  id int primary key default 1 check(id=1),
  eyebrow text not null default 'Officially authorized fan experiences',
  title text not null default 'Closer to the artists',
  highlight text not null default 'you love.',
  subtitle text not null default 'A premium fan-club platform for memberships, meet & greets and curated experiences. Fund your wallet, book in seconds and manage everything from one secure dashboard.',
  featured_heading text not null default 'Featured artists',
  featured_subheading text not null default 'Meet the artists you can book right now.',
  logo_url text,
  updated_at timestamptz not null default now()
);
alter table public.homepage_settings add column if not exists logo_url text;
insert into public.homepage_settings(id) values(1) on conflict do nothing;

create table if not exists public.featured_artists(
  id uuid primary key default gen_random_uuid(),
  name text not null,
  tagline text not null default '',
  image_url text,
  kind public.package_kind not null default 'meet_greet',
  package_id uuid references public.packages(id) on delete set null,
  sort_order int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.featured_artists add column if not exists package_id uuid references public.packages(id) on delete set null;

alter table public.homepage_settings enable row level security;
alter table public.featured_artists enable row level security;

drop policy if exists "homepage_settings public read" on public.homepage_settings;
drop policy if exists "homepage_settings admin write" on public.homepage_settings;
drop policy if exists "featured_artists public read active" on public.featured_artists;
drop policy if exists "featured_artists admin write" on public.featured_artists;
create policy "homepage_settings public read" on public.homepage_settings for select to anon, authenticated using (true);
create policy "homepage_settings admin write" on public.homepage_settings for all to authenticated using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));
create policy "featured_artists public read active" on public.featured_artists for select to anon, authenticated using (active or public.is_admin(auth.uid()));
create policy "featured_artists admin write" on public.featured_artists for all to authenticated using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- Storage bucket for the site logo (public read, admin-only write, 2 MB, images only)
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('site-assets','site-assets',true,2097152,array['image/png','image/jpeg','image/webp','image/svg+xml','image/gif'])
on conflict (id) do update set public=true,file_size_limit=2097152,allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "site-assets public read" on storage.objects;
drop policy if exists "site-assets admin insert" on storage.objects;
drop policy if exists "site-assets admin update" on storage.objects;
drop policy if exists "site-assets admin delete" on storage.objects;
create policy "site-assets public read" on storage.objects for select to anon, authenticated using (bucket_id='site-assets');
create policy "site-assets admin insert" on storage.objects for insert to authenticated with check (bucket_id='site-assets' and public.is_admin(auth.uid()));
create policy "site-assets admin update" on storage.objects for update to authenticated using (bucket_id='site-assets' and public.is_admin(auth.uid())) with check (bucket_id='site-assets' and public.is_admin(auth.uid()));
create policy "site-assets admin delete" on storage.objects for delete to authenticated using (bucket_id='site-assets' and public.is_admin(auth.uid()));
