-- FanMeet schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;
create type public.user_role as enum ('fan','admin');
create type public.package_kind as enum ('meet_greet','fan_club');
create type public.deposit_status as enum ('pending','approved','rejected');
create type public.transaction_type as enum ('deposit','booking','refund','adjustment');
create type public.booking_status as enum ('pending','confirmed','completed','cancelled');

create table public.profiles(id uuid primary key references auth.users(id) on delete cascade,full_name text,email text,role public.user_role not null default 'fan',created_at timestamptz not null default now());
create table public.wallets(user_id uuid primary key references public.profiles(id) on delete cascade,balance numeric(14,2) not null default 0,updated_at timestamptz not null default now());
create table public.payment_methods(id uuid primary key default gen_random_uuid(),name text not null,instructions text not null,active boolean not null default true,created_at timestamptz not null default now());
create table public.packages(id uuid primary key default gen_random_uuid(),name text not null,description text not null default '',price numeric(14,2) not null check(price>0),kind public.package_kind not null,artist_name text not null,image_url text,active boolean not null default true,created_at timestamptz not null default now());
create table public.deposits(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles(id),payment_method_id uuid references public.payment_methods(id),amount numeric(14,2) not null check(amount>0),reference text not null,note text,status public.deposit_status not null default 'pending',created_at timestamptz not null default now(),reviewed_at timestamptz,reviewed_by uuid references public.profiles(id));
create table public.wallet_transactions(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles(id),type public.transaction_type not null,amount numeric(14,2) not null,description text not null,reference_id uuid,created_at timestamptz not null default now());
create table public.bookings(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles(id),package_id uuid not null references public.packages(id),amount numeric(14,2) not null,status public.booking_status not null default 'pending',created_at timestamptz not null default now());

create index deposits_user_idx on public.deposits(user_id,created_at desc);
create index tx_user_idx on public.wallet_transactions(user_id,created_at desc);
create index bookings_user_idx on public.bookings(user_id,created_at desc);

create or replace function public.is_admin(uid uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles where id=uid and role='admin'); $$;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id,full_name,email) values(new.id,new.raw_user_meta_data->>'full_name',new.email); insert into public.wallets(user_id) values(new.id); return new; end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.approve_deposit(p_deposit_id uuid) returns void language plpgsql security definer set search_path=public as $$ declare d public.deposits; admin_id uuid:=auth.uid(); begin if not public.is_admin(admin_id) then raise exception 'Forbidden'; end if; select * into d from public.deposits where id=p_deposit_id for update; if d.id is null then raise exception 'Deposit not found'; end if; if d.status <> 'pending' then raise exception 'Deposit already reviewed'; end if; update public.deposits set status='approved',reviewed_at=now(),reviewed_by=admin_id where id=d.id; update public.wallets set balance=balance+d.amount,updated_at=now() where user_id=d.user_id; insert into public.wallet_transactions(user_id,type,amount,description,reference_id) values(d.user_id,'deposit',d.amount,'Approved wallet deposit',d.id); end; $$;

create or replace function public.admin_adjust_wallet(p_user_id uuid,p_amount numeric,p_note text) returns void language plpgsql security definer set search_path=public as $$ begin if not public.is_admin(auth.uid()) then raise exception 'Forbidden'; end if; if p_amount=0 then raise exception 'Amount cannot be zero'; end if; if p_amount<0 and (select balance+p_amount from public.wallets where user_id=p_user_id)<0 then raise exception 'Insufficient balance'; end if; update public.wallets set balance=balance+p_amount,updated_at=now() where user_id=p_user_id; if not found then raise exception 'Wallet not found'; end if; insert into public.wallet_transactions(user_id,type,amount,description) values(p_user_id,'adjustment',p_amount,p_note); end; $$;

create or replace function public.create_booking(p_package_id uuid) returns uuid language plpgsql security definer set search_path=public as $$ declare uid uuid:=auth.uid(); p public.packages; b_id uuid; begin if uid is null then raise exception 'Unauthorized'; end if; select * into p from public.packages where id=p_package_id and active=true; if p.id is null then raise exception 'Package unavailable'; end if; update public.wallets set balance=balance-p.price,updated_at=now() where user_id=uid and balance>=p.price; if not found then raise exception 'Insufficient wallet balance'; end if; insert into public.bookings(user_id,package_id,amount) values(uid,p.id,p.price) returning id into b_id; insert into public.wallet_transactions(user_id,type,amount,description,reference_id) values(uid,'booking',-p.price,'Package booking',b_id); return b_id; end; $$;

alter table public.profiles enable row level security;alter table public.wallets enable row level security;alter table public.payment_methods enable row level security;alter table public.packages enable row level security;alter table public.deposits enable row level security;alter table public.wallet_transactions enable row level security;alter table public.bookings enable row level security;
create policy "profiles own read" on public.profiles for select using(id=auth.uid() or public.is_admin(auth.uid()));
create policy "wallet own read" on public.wallets for select using(user_id=auth.uid() or public.is_admin(auth.uid()));
create policy "methods public read" on public.payment_methods for select using(active=true or public.is_admin(auth.uid()));
create policy "packages public read" on public.packages for select using(active=true or public.is_admin(auth.uid()));
create policy "deposits own read" on public.deposits for select using(user_id=auth.uid() or public.is_admin(auth.uid()));
create policy "deposits own insert" on public.deposits for insert with check(user_id=auth.uid());
create policy "transactions own read" on public.wallet_transactions for select using(user_id=auth.uid() or public.is_admin(auth.uid()));
create policy "bookings own read" on public.bookings for select using(user_id=auth.uid() or public.is_admin(auth.uid()));
create policy "admin profiles write" on public.profiles for all using(public.is_admin(auth.uid())) with check(public.is_admin(auth.uid()));
create policy "admin methods write" on public.payment_methods for all using(public.is_admin(auth.uid())) with check(public.is_admin(auth.uid()));
create policy "admin packages write" on public.packages for all using(public.is_admin(auth.uid())) with check(public.is_admin(auth.uid()));

insert into public.payment_methods(name,instructions) values('Bank Transfer','Demo instructions: Admin will replace this with authorized bank details before launch.'),('PayPal','Demo instructions: Configure an authorized PayPal account before launch.');
insert into public.packages(name,description,price,kind,artist_name) values('Premium Meet & Greet','Reserved meet & greet experience. Demo catalog item.',500,'meet_greet','Artist One'),('Fan Club Membership','Annual fan club membership with member benefits.',100,'fan_club','Artist One'),('VIP Meet & Greet','Premium experience for an authorized artist event.',750,'meet_greet','Artist Two');
-- After creating your own admin account, promote it with:
-- update public.profiles set role='admin' where email='YOUR_ADMIN_EMAIL';

-- Enable Realtime for live wallet balance updates in the dashboard.
alter publication supabase_realtime add table public.wallets;
