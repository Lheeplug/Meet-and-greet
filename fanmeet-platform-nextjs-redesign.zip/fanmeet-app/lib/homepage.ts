import { cache } from 'react';
import { createClient } from '@/lib/supabase/server';

export type HomepageSettings = { eyebrow: string; title: string; highlight: string; subtitle: string; featured_heading: string; featured_subheading: string; logo_url: string };
export type FeaturedArtist = { id: string; name: string; tagline: string; image_url: string | null; kind: 'meet_greet' | 'fan_club'; sort_order: number; active: boolean; package_id: string | null; price: number | null };

export const defaultHomepage: HomepageSettings = {
  eyebrow: 'Officially authorized fan experiences',
  title: 'Closer to the artists',
  highlight: 'you love.',
  subtitle: 'A premium fan-club platform for memberships, meet & greets and curated experiences. Fund your wallet, book in seconds and manage everything from one secure dashboard.',
  featured_heading: 'Featured artists',
  featured_subheading: 'Meet the artists you can book right now.',
  logo_url: '',
};

// One settings query per request, shared by the header, footer and homepage.
const getSettingsRow = cache(async () => {
  const s = await createClient();
  const { data } = await s.from('homepage_settings').select('*').eq('id', 1).maybeSingle();
  return data;
});

export async function getSiteLogo(): Promise<string | null> {
  const row = await getSettingsRow();
  return (row?.logo_url as string | null) || null;
}

// Falls back to defaults if the homepage tables don't exist yet or are empty.
export async function getHomepage() {
  const s = await createClient();
  const [row, { data: artists }] = await Promise.all([
    getSettingsRow(),
    s.from('featured_artists').select('*,packages(price,active)').eq('active', true).order('sort_order').order('created_at', { ascending: false }),
  ]);
  const settings = { ...defaultHomepage };
  if (row) for (const k of Object.keys(defaultHomepage) as (keyof HomepageSettings)[]) if (row[k]) settings[k] = row[k];
  const list: FeaturedArtist[] = (artists ?? []).map((a: any) => {
    const pkg = Array.isArray(a.packages) ? a.packages[0] : a.packages;
    const { packages: _p, ...rest } = a;
    return { ...rest, price: pkg && pkg.active ? Number(pkg.price) : null };
  });
  return { settings, artists: list };
}
