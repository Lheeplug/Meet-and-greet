export type Profile = { id:string; full_name:string|null; email:string|null; role:'fan'|'admin'; created_at:string };
export type Wallet = { user_id:string; balance:number; updated_at:string };
export type Package = { id:string; name:string; description:string; price:number; kind:'meet_greet'|'fan_club'; artist_name:string; image_url:string|null; active:boolean };
export type PaymentMethod = { id:string; name:string; instructions:string; active:boolean };
