import { createClient } from '@/lib/supabase/server';
export async function getCurrentUser(){const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();return user}
export async function getProfile(){const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)return null;const {data}=await supabase.from('profiles').select('*').eq('id',user.id).single();return data}
