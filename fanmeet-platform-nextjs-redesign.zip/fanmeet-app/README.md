# FanMeet Platform — Next.js + Vercel + Supabase

A production-oriented starter for an authorized fan club / meet & greet platform. It includes authentication, a wallet ledger, manual/demo deposits, admin review, packages, bookings, and RLS-protected Supabase data.

## Stack
- Next.js 16 App Router
- React 19
- Supabase Auth + PostgreSQL + RLS
- Vercel deployment

Supabase's current Next.js guidance uses `@supabase/ssr` with cookie-based sessions. See the official docs linked below.

## Local setup
1. Create a Supabase project.
2. Open Supabase SQL Editor and run `supabase/schema.sql`.
3. Copy `.env.example` to `.env.local` and add your Supabase URL + publishable key.
4. Install and run:
   `npm install`
   `npm run dev`
5. Create a fan account.
6. Promote your admin account in Supabase SQL:
   `update public.profiles set role='admin' where email='YOUR_ADMIN_EMAIL';`
7. Visit `/admin`.

## Supabase email confirmation
If email confirmation is enabled, configure the confirmation email to use the `/auth/confirm?token_hash={{ .TokenHash }}&type=email` pattern recommended by Supabase's SSR guide.

## Demo payment flow
This starter deliberately does not pretend that a payment occurred. A fan submits a deposit request with a payment method/reference; the admin approves it. Approval calls a server-side Postgres function that atomically credits the wallet and records a transaction.

For production, connect a real authorized payment processor and only credit the wallet after a verified server-to-server payment confirmation/webhook.

## Vercel
Push the repository to GitHub, import it into Vercel, and add the same environment variables in Project Settings. Vercel automatically detects Next.js projects.

## Security notes
- Wallet changes happen server-side through database functions.
- RLS is enabled on user data.
- Never expose a Supabase service-role key to the browser.
- Use authorized branding, payment accounts, and event/artist information.

## Production checklist
- Replace demo payment instructions with your authorized payment methods.
- Add a verified payment gateway webhook before enabling automatic deposits.
- Configure your production Site URL and redirect URLs in Supabase Auth.
- Configure a custom domain in Vercel.
- Review Supabase RLS policies before launch.
- Add rate limiting, audit logging, email notifications, and fraud/chargeback handling for a real-money deployment.
- Use only branding/content you are authorized to operate.
